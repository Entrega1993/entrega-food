# Entrega.food

A clean Next.js + Tailwind site for a modern food delivery business.

## Run locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000
