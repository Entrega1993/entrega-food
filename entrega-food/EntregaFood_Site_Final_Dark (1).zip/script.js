const esBtn=document.getElementById('esBtn');const enBtn=document.getElementById('enBtn');
function setLang(lang){document.querySelectorAll('[data-es]').forEach(el=>{el.textContent= lang==='es'?el.getAttribute('data-es'):el.getAttribute('data-en')}); 
  if(lang==='es'){esBtn.classList.add('active');enBtn.classList.remove('active')} else {enBtn.classList.add('active');esBtn.classList.remove('active')}
  localStorage.setItem('lang',lang);
}
esBtn&&esBtn.addEventListener('click',()=>setLang('es'));
enBtn&&enBtn.addEventListener('click',()=>setLang('en'));
setLang(localStorage.getItem('lang')||'es');
